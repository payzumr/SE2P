var class_dispatcher =
[
    [ "~Dispatcher", "class_dispatcher.html#a52fc4e8bef278fa415723b39b61c28a7", null ],
    [ "execute", "class_dispatcher.html#a43e6543555c3ddc20e108a6b5a3647b7", null ],
    [ "shutdown", "class_dispatcher.html#aba342cec514e992de9b3c22e1e451d50", null ],
    [ "testzeitD", "class_dispatcher.html#a95fab461b2ed28ed3d2d0b73fb9d261d", null ]
];