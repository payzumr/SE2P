var dir_86d975b04dfd16ce93339a2e81fe62c0 =
[
    [ "Controller1.cpp", "_controller1_8cpp.html", "_controller1_8cpp" ],
    [ "Controller1.h", "_controller1_8h.html", [
      [ "Controller1", "class_controller1.html", "class_controller1" ],
      [ "puk", "struct_controller1_1_1puk.html", "struct_controller1_1_1puk" ]
    ] ],
    [ "Controller2.cpp", "_controller2_8cpp.html", "_controller2_8cpp" ],
    [ "Controller2.h", "_controller2_8h.html", [
      [ "Controller2", "class_controller2.html", "class_controller2" ],
      [ "puk", "struct_controller2_1_1puk.html", "struct_controller2_1_1puk" ]
    ] ],
    [ "Dispatcher.cpp", "_dispatcher_8cpp.html", "_dispatcher_8cpp" ],
    [ "Dispatcher.h", "_dispatcher_8h.html", [
      [ "Dispatcher", "class_dispatcher.html", "class_dispatcher" ]
    ] ],
    [ "PetriDefines.h", "_petri_defines_8h.html", "_petri_defines_8h" ],
    [ "PukType.h", "_puk_type_8h.html", "_puk_type_8h" ]
];