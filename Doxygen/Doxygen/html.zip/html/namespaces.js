var namespaces =
[
    [ "hal", "namespacehal.html", null ],
    [ "thread", "namespacethread.html", null ]
];