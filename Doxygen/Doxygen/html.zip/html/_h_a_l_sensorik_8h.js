var _h_a_l_sensorik_8h =
[
    [ "HALSensorik", "classhal_1_1_h_a_l_sensorik.html", "classhal_1_1_h_a_l_sensorik" ],
    [ "ISR", "_h_a_l_sensorik_8h.html#a20a93d69d4c85d322500e6f8a6053b3d", null ]
];