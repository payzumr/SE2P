var namespacehal =
[
    [ "Blinki", "classhal_1_1_blinki.html", "classhal_1_1_blinki" ],
    [ "HALSensorik", "classhal_1_1_h_a_l_sensorik.html", "classhal_1_1_h_a_l_sensorik" ]
];