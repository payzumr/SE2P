var annotated =
[
    [ "hal", "namespacehal.html", "namespacehal" ],
    [ "thread", "namespacethread.html", "namespacethread" ],
    [ "Controller1", "class_controller1.html", "class_controller1" ],
    [ "Controller2", "class_controller2.html", "class_controller2" ],
    [ "Dispatcher", "class_dispatcher.html", "class_dispatcher" ],
    [ "HALAktorik", "class_h_a_l_aktorik.html", "class_h_a_l_aktorik" ],
    [ "Initialisation", "class_initialisation.html", "class_initialisation" ],
    [ "LightControl", "class_light_control.html", "class_light_control" ],
    [ "MachineState", "class_machine_state.html", "class_machine_state" ],
    [ "Mutex", "class_mutex.html", "class_mutex" ],
    [ "Serial", "class_serial.html", "class_serial" ],
    [ "Test", "class_test.html", "class_test" ]
];