var struct_serial_1_1packet =
[
    [ "acktype", "struct_serial_1_1packet.html#aba4a4f65df28c6d5ea6eafe506dc1925", null ],
    [ "height1", "struct_serial_1_1packet.html#a155ca8c87f5ca609a6a8686c01036d41", null ],
    [ "pukId", "struct_serial_1_1packet.html#ae05d7c7b5c30e897e6375d506e6922a1", null ],
    [ "status", "struct_serial_1_1packet.html#a7a377813c0032e085d2460695084abe9", null ],
    [ "type", "struct_serial_1_1packet.html#a13933d2b5171290fab712e42aa50c8f0", null ]
];