var struct_controller1_1_1puk =
[
    [ "height1", "struct_controller1_1_1puk.html#ae8f3c14925bfb035412f3095da75960f", null ],
    [ "height2", "struct_controller1_1_1puk.html#a4b17e86ab56bc3a19c836d862cef2a65", null ],
    [ "metall", "struct_controller1_1_1puk.html#af2da9c54715db1b7b7c4e8e3a0d1f602", null ],
    [ "place", "struct_controller1_1_1puk.html#ab4343c8da9cf7206fa5dcb3f92150be8", null ],
    [ "pukIdentifier", "struct_controller1_1_1puk.html#a8b9e5abfd48f58fd47ed4805fc3abf8d", null ],
    [ "type", "struct_controller1_1_1puk.html#a6ee776407907fa37d596d442f9a374ad", null ]
];