var class_initialisation =
[
    [ "~Initialisation", "class_initialisation.html#a4c0a097c80f3f28f6a9e5b6e6e0843b6", null ],
    [ "execute", "class_initialisation.html#a20e044c67aeb22040d1b38b71d0ebb5d", null ],
    [ "shutdown", "class_initialisation.html#afab7d7a18ca9aef606773bb8133ae48d", null ],
    [ "testzeitD", "class_initialisation.html#a7ceb48642bb2543433381e1d5e5ffffa", null ]
];