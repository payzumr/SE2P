var struct_controller2_1_1puk =
[
    [ "height1", "struct_controller2_1_1puk.html#ad46b982d58447f4f4b41c25eb13f79f5", null ],
    [ "height2", "struct_controller2_1_1puk.html#acc16126d1c1c04e8cc0139c427f328f1", null ],
    [ "metall", "struct_controller2_1_1puk.html#a32a1f7dca77ad383666b4b49cae34ed6", null ],
    [ "place", "struct_controller2_1_1puk.html#a5c86caebf92057fdb0058d15ffeb5004", null ],
    [ "pukIdentifier", "struct_controller2_1_1puk.html#ac2833d20a4e0596ebe471cdd056ae40e", null ],
    [ "type", "struct_controller2_1_1puk.html#a9c77afe05944dd82695fa05f4ecbd6a3", null ]
];