var searchData=
[
  ['controller1',['Controller1',['../class_controller1.html',1,'']]],
  ['controller2',['Controller2',['../class_controller2.html',1,'']]]
];
