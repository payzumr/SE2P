var searchData=
[
  ['inheightmeasure',['INHEIGHTMEASURE',['../_petri_defines_8h.html#aa58367dd79215a00c4c39893ebd88d03',1,'PetriDefines.h']]],
  ['inswitchhole',['INSWITCHHOLE',['../_petri_defines_8h.html#a0639b449c4dec12255e1442b8dbed8b4',1,'PetriDefines.h']]],
  ['inswitchnonhole',['INSWITCHNONHOLE',['../_petri_defines_8h.html#ae43b7f70b11cc1a3bb2ef24e08d9f44a',1,'PetriDefines.h']]],
  ['inswitchnonholemetal',['INSWITCHNONHOLEMETAL',['../_petri_defines_8h.html#aba52623e7c9e80f124fce8b7abe5dfe4',1,'PetriDefines.h']]],
  ['inswitchnonmetal',['INSWITCHNONMETAL',['../_petri_defines_8h.html#a162c134869f96c56230e81852cd77e7e',1,'PetriDefines.h']]]
];
