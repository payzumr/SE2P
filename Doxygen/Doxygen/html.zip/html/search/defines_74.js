var searchData=
[
  ['test_5fmessages',['TEST_MESSAGES',['../_test_8cpp.html#a16b15eb1be25e2590567f87fdcc5fe0e',1,'Test.cpp']]],
  ['test_5ftime',['TEST_TIME',['../main_8cc.html#a9adcfa1dcb92dd0d8757264ae41d1710',1,'main.cc']]],
  ['timercnt',['TIMERCNT',['../_timer_8cpp.html#aea7a66a8027365e5366a23ed134e11b2',1,'Timer.cpp']]],
  ['turn_5ftime',['TURN_TIME',['../_addresses_8h.html#aea0d8480f835303c2d54e9b5bb2c0cf1',1,'Addresses.h']]],
  ['turnplacece',['TURNPLACECE',['../_petri_defines_8h.html#ae0884b2d82bc23b34b2ccb562826e283',1,'PetriDefines.h']]]
];
