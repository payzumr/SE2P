var searchData=
[
  ['metallnotok',['METALLNOTOK',['../_petri_defines_8h.html#a256146b254a974dd474af682d45e5859',1,'PetriDefines.h']]],
  ['metallsensor',['METALLSENSOR',['../_test_8cpp.html#a055461f7127445ddea2d0b1565dd2117',1,'Test.cpp']]],
  ['msg_5flength',['MSG_LENGTH',['../_test_8cpp.html#aa204ec58d846f2354e6bd239460db89f',1,'Test.cpp']]]
];
