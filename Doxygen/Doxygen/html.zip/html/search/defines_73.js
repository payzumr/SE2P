var searchData=
[
  ['sensors',['SENSORS',['../_addresses_8h.html#a11d038bc0d376b5a6a7634604b6e058d',1,'Addresses.h']]],
  ['sleep_5fone_5fsec',['SLEEP_ONE_SEC',['../_test_8cpp.html#a15ba033dbe556975bfeb6caa3a046753',1,'Test.cpp']]],
  ['sleep_5ftwo_5fsec',['SLEEP_TWO_SEC',['../_thread_8cpp.html#ac798017ae8b3975517e44c575f7fad26',1,'Thread.cpp']]],
  ['slide_5ftime',['SLIDE_TIME',['../_addresses_8h.html#aa1ba739f9ffceb2fda1b8bc8a41af122',1,'Addresses.h']]],
  ['slideplace',['SLIDEPLACE',['../_petri_defines_8h.html#a14aacef35e5bc0863327516197683f5a',1,'PetriDefines.h']]],
  ['start',['START',['../_addresses_8h.html#a3018c7600b7bb9866400596a56a57af7',1,'Addresses.h']]],
  ['startexitnonpartholemetal',['STARTEXITNONPARTHOLEMETAL',['../_petri_defines_8h.html#a1db9d8d18db9a2b79b2b3f6ef1fe6bbd',1,'PetriDefines.h']]],
  ['startexitpart',['STARTEXITPART',['../_petri_defines_8h.html#af92c3de2efae8be51cf0f3e99dd4792a',1,'PetriDefines.h']]],
  ['startexitparthole',['STARTEXITPARTHOLE',['../_petri_defines_8h.html#a89cf352b4354e3543379919956114726',1,'PetriDefines.h']]],
  ['starttaste',['STARTTASTE',['../_test_8cpp.html#aaa3b24374b32300baa57b21d6fa13beb',1,'Test.cpp']]],
  ['stop',['STOP',['../_addresses_8h.html#ae19b6bb2940d2fbe0a79852b070eeafd',1,'Addresses.h']]],
  ['stoplights',['STOPLIGHTS',['../_addresses_8h.html#a65146bde734127c1d961272a810a3305',1,'Addresses.h']]],
  ['stoptaste',['STOPTASTE',['../_test_8cpp.html#aa46b00e9bb4a5287f600028ac6a87e8a',1,'Test.cpp']]],
  ['switch_5fopen_5ftime',['SWITCH_OPEN_TIME',['../_addresses_8h.html#aa2e69649066d1f68d5c017a1ffd4452a',1,'Addresses.h']]]
];
