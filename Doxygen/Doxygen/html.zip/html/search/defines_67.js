var searchData=
[
  ['green',['GREEN',['../_addresses_8h.html#acfbc006ea433ad708fdee3e82996e721',1,'Addresses.h']]]
];
