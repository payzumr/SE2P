var searchData=
[
  ['n_5fpuks',['N_PUKS',['../_petri_defines_8h.html#a19d163720b32fd24c35b94fe32b1c648',1,'PetriDefines.h']]],
  ['n_5ftimer',['N_TIMER',['../_timer_8h.html#a38a78ae01a179694e82cee394261c62e',1,'Timer.h']]],
  ['nonholepukhm',['NONHOLEPUKHM',['../_petri_defines_8h.html#ae90c936a0fd72cc5456b7f86aa665321',1,'PetriDefines.h']]]
];
