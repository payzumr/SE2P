var searchData=
[
  ['dispatcher',['Dispatcher',['../class_dispatcher.html',1,'']]]
];
